require("dotenv").config();

const cors = require("cors");
const express = require("express");
const http = require("http");

const { connectDB } = require("./config/db");
const authRoutes = require("./routes/authRoutes");
const billingRoutes = require("./routes/billingRoutes");
const bookingPaymentRoutes = require("./routes/bookingPaymentRoutes");
const chatRoutes = require("./routes/chatRoutes");
const notificationRoutes = require("./routes/notificationRoutes");
const { stripeWebhook } = require("./controllers/billingController");
const integrationRoutes = require("./routes/integrationRoutes");
const moderatorProfileRoutes = require("./routes/moderatorProfileRoutes");
const aiRoutes = require("./routes/aiRoutes");
const staffRoutes = require("./routes/staffRoutes");
const attendanceRoutes = require("./routes/attendanceRoutes");
const payrollRoutes = require("./routes/payrollRoutes");
const adminRoutes = require("./routes/adminRoutes");
const subscriptionRoutes = require("./routes/subscriptionRoutes");
const { initializeChatSocket } = require("./socket/chatSocket");
const { initializeWhatnotExtensionBridge } = require("./socket/whatnotExtensionBridge");
const { startPendingInventoryAutoSyncWorker } = require("./services/pendingInventoryService");
const models = require("./models");

const app = express();

const configuredOrigins = (process.env.FRONTEND_URL || "")
  .split(",")
  .map((origin) => origin.trim())
  .filter(Boolean);

const allowedOrigins = Array.from(
  new Set([...configuredOrigins, "http://localhost:3000", "http://localhost:3001"]),
);

app.use(
  cors({
    origin(origin, callback) {
      const isChromeExtensionOrigin = typeof origin === "string" && origin.startsWith("chrome-extension://");

      if (!origin || isChromeExtensionOrigin || allowedOrigins.includes(origin)) {
        return callback(null, true);
      }

      return callback(new Error("CORS: origin not allowed"));
    },
  }),
);
app.post(
  "/api/billing/webhooks/stripe",
  express.raw({ type: "application/json" }),
  stripeWebhook,
);
function createJsonMiddleware() {
  const defaultParser = express.json({ limit: "1mb" });
  const largeBodyParser = express.json({ limit: "25mb" });
  const largeBodyPaths = new Set([
    "/api/integrations/whatnot/media/upload-urls",
    "/api/staff/pending-inventory",
  ]);
  return (req, res, next) => {
    const url = typeof req.originalUrl === "string" ? req.originalUrl.split("?")[0] : "";
    const useLargeBodyParser = req.method === "POST" && largeBodyPaths.has(url);
    return (useLargeBodyParser ? largeBodyParser : defaultParser)(req, res, next);
  };
}

app.use(createJsonMiddleware());

app.use("/api/auth", authRoutes);
app.use("/api/billing", billingRoutes);
app.use("/api/booking-payments", bookingPaymentRoutes);
app.use("/api/chat", chatRoutes);
app.use("/api/notifications", notificationRoutes);
app.use("/api/integrations", integrationRoutes);
app.use("/api/moderator-profile", moderatorProfileRoutes);
app.use("/api/ai", aiRoutes);
app.use("/api/staff", staffRoutes);
app.use("/api/attendance", attendanceRoutes);
app.use("/api/payroll", payrollRoutes);
app.use("/api/admin", adminRoutes);
app.use("/api/subscriptions", subscriptionRoutes);

app.get("/health", (req, res) => {
  res.json({ ok: true, models: Object.keys(models).length });
});

async function start() {
  await connectDB(process.env.MONGODB_URI || "mongodb://localhost:27017/sellerhub");
  const port = process.env.PORT || 5000;
  const server = http.createServer(app);
  initializeChatSocket({ server, allowedOrigins });
  initializeWhatnotExtensionBridge({ server });
  startPendingInventoryAutoSyncWorker();
  server.listen(port, () => console.log(`Server running on ${port}`));
}

start().catch((err) => {
  console.error(err);
  process.exit(1);
});
