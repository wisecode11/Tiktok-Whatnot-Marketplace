const { createClerkClient } = require("@clerk/backend");

const User = require("../models/Users");
const SellerWorkspace = require("../models/SellerWorkspace");
const WorkspaceMembership = require("../models/WorkspaceMembership");
const WhatnotLiveStatsSnapshot = require("../models/WhatnotLiveStatsSnapshot");
const WhatnotShipmentDetail = require("../models/WhatnotShipmentDetail");
const { getEmailDeliveryErrorMessage, sendStaffWelcomeEmail } = require("./emailService");
const {
  resolveActiveSellerWorkspaceForSeller,
  syncSellerOrganizationMembers,
} = require("./authService");

function createHttpError(status, message, details) {
  const error = new Error(message);
  error.status = status;
  error.details = details;
  return error;
}

function normalizeClerkError(error, fallbackMessage) {
  if (error && Array.isArray(error.errors) && error.errors.length > 0) {
    const firstError = error.errors[0];
    return createHttpError(
      422,
      firstError.longMessage || firstError.message || fallbackMessage,
      {
        errors: error.errors,
      },
    );
  }

  return createHttpError(422, fallbackMessage);
}

function getClerkClient() {
  return createClerkClient({ secretKey: process.env.CLERK_SECRET_KEY });
}

function normalizeEmail(email) {
  return typeof email === "string" ? email.trim().toLowerCase() : "";
}

function normalizeUsername(username) {
  return typeof username === "string" ? username.trim() : "";
}

function normalizePassword(password) {
  return typeof password === "string" ? password.trim() : "";
}

function buildStaffNameParts(username) {
  const cleaned = normalizeUsername(username).replace(/[._-]+/g, " ").trim();

  if (!cleaned) {
    return {
      firstName: "Staff",
      lastName: "Member",
    };
  }

  const parts = cleaned.split(/\s+/).filter(Boolean);

  if (parts.length === 1) {
    return {
      firstName: parts[0],
      lastName: "Staff",
    };
  }

  return {
    firstName: parts[0],
    lastName: parts.slice(1).join(" "),
  };
}

function buildLoginUrl() {
  const frontendUrl = (process.env.FRONTEND_URL || "http://localhost:3000").split(",")[0].trim();
  return `${frontendUrl.replace(/\/$/, "")}/login?role=staff`;
}

async function ensureStaffClerkOrganizationMembership({ clerkClient, clerkUserId, workspace }) {
  const organizationId =
    workspace && typeof workspace.clerk_organization_id === "string"
      ? workspace.clerk_organization_id.trim()
      : "";

  if (!organizationId) {
    return false;
  }

  try {
    await clerkClient.organizations.createOrganizationMembership({
      organizationId,
      userId: clerkUserId,
      role: "org:member",
    });
    return true;
  } catch (error) {
    const clerkErrors = error && Array.isArray(error.errors) ? error.errors : [];
    const isAlreadyMember = clerkErrors.some((entry) => {
      const code = entry && typeof entry.code === "string" ? entry.code : "";
      return code === "already_a_member_in_organization" || code === "duplicate_record";
    });

    if (isAlreadyMember) {
      return true;
    }

    throw normalizeClerkError(error, "Unable to add the staff member to the seller organization.");
  }
}

function buildStreamerDisplayName(seller) {
  const fullName = [seller.first_name, seller.last_name].filter(Boolean).join(" ").trim();
  if (fullName) {
    return fullName;
  }
  return seller.email || "Streamer";
}

async function findAuthenticatedSeller(clerkUserId) {
  const user = await User.findOne({ clerk_user_id: clerkUserId });

  if (!user) {
    throw createHttpError(404, "Seller account was not found.");
  }

  if (user.user_type !== "seller") {
    throw createHttpError(403, "Only streamers can manage staff.");
  }

  return user;
}

async function ensureSellerWorkspace(seller) {
  return resolveActiveSellerWorkspaceForSeller(seller);
}

async function syncWorkspaceOrganizationMembers({ clerkUserId, workspace }) {
  const organizationId =
    workspace && typeof workspace.clerk_organization_id === "string"
      ? workspace.clerk_organization_id.trim()
      : "";

  if (!organizationId) {
    return;
  }

  await syncSellerOrganizationMembers({
    clerkUserId,
    clerkOrganizationId: organizationId,
  });

  await consolidateStaffMembershipsForWorkspace(workspace._id);
}

function formatStaffDisplayName(user) {
  if (!user) {
    return "Unknown";
  }

  const fullName = [user.first_name, user.last_name].filter(Boolean).join(" ").trim();
  return fullName || user.email || "Unknown";
}

/**
 * Active staff memberships that have a matching User record (same rule as Manage Staff).
 * Orphan memberships (no User) are revoked so payroll does not list "Unknown" rows.
 */
async function getActiveStaffWithUsers(workspaceId, { revokeOrphanMemberships = true } = {}) {
  const memberships = await WorkspaceMembership.find({
    workspace_id: workspaceId,
    role: "staff",
    status: "active",
  });

  const userIds = [...new Set(memberships.map((membership) => membership.user_id).filter(Boolean))];
  const users = await User.find({ _id: { $in: userIds } });
  const userById = new Map(users.map((user) => [user._id, user]));

  const staff = [];
  const orphanMembershipIds = [];

  for (const membership of memberships) {
    const user = membership.user_id ? userById.get(membership.user_id) : null;
    if (user) {
      staff.push({ membership, user });
    } else if (membership._id) {
      orphanMembershipIds.push(membership._id);
    }
  }

  if (revokeOrphanMemberships && orphanMembershipIds.length > 0) {
    const now = new Date();
    await WorkspaceMembership.updateMany(
      { _id: { $in: orphanMembershipIds } },
      { $set: { status: "revoked", updated_at: now } },
    );
  }

  return {
    staff,
    staffUserIds: staff.map((entry) => entry.user._id),
    userMap: Object.fromEntries(staff.map((entry) => [entry.user._id, entry.user])),
    revokedOrphanCount: orphanMembershipIds.length,
  };
}

function serializeStaffMember({ user, membership }) {
  const permissions = membership && membership.permissions_json ? membership.permissions_json : {};
  const modules = Array.isArray(permissions.modules) ? permissions.modules : [];

  return {
    id: user._id,
    clerkUserId: user.clerk_user_id,
    username: permissions.username || null,
    email: user.email,
    firstName: user.first_name || "",
    lastName: user.last_name || "",
    role: "staff",
    status: membership && membership.status ? membership.status : user.status,
    streamerUserId: user.parent_seller_user_id || null,
    workspaceId: membership ? membership.workspace_id : null,
    modules,
    joinedAt: membership && membership.joined_at ? membership.joined_at : null,
    createdAt: user.created_at || null,
    source: permissions.source || null,
  };
}

function scoreStaffMembershipEntry({ membership, user }) {
  let score = 0;

  if (user && membership.user_id) {
    score += 10;
  }

  if (membership.status === "active") {
    score += 5;
  }

  if (membership.joined_at) {
    score += 1;
  }

  return score;
}

async function consolidateStaffMembershipsForWorkspace(workspaceId) {
  const memberships = await WorkspaceMembership.find({
    workspace_id: workspaceId,
    role: "staff",
    status: { $in: ["active", "invited"] },
  });

  if (memberships.length <= 1) {
    return;
  }

  const userIds = memberships.map((membership) => membership.user_id).filter(Boolean);
  const users = await User.find({ _id: { $in: userIds } });
  const userById = new Map(users.map((user) => [String(user._id), user]));

  const groupsByEmail = new Map();

  for (const membership of memberships) {
    const user = membership.user_id ? userById.get(String(membership.user_id)) : null;
    const email = (user && user.email ? user.email : membership.permissions_json?.email || "")
      .trim()
      .toLowerCase();

    if (!email) {
      continue;
    }

    const group = groupsByEmail.get(email) || [];
    group.push({ membership, user });
    groupsByEmail.set(email, group);
  }

  const now = new Date();

  for (const [, group] of groupsByEmail) {
    if (group.length <= 1) {
      continue;
    }

    const sorted = [...group].sort(
      (a, b) => scoreStaffMembershipEntry(b) - scoreStaffMembershipEntry(a),
    );
    const keeper = sorted[0];
    const revokeIds = sorted.slice(1).map((entry) => entry.membership._id);

    if (keeper.user) {
      keeper.membership.user_id = keeper.user._id;
      keeper.membership.status = "active";
      keeper.membership.role = "staff";
      keeper.membership.joined_at = keeper.membership.joined_at || now;
      keeper.membership.permissions_json = {
        ...(keeper.membership.permissions_json || {}),
        email: keeper.user.email.toLowerCase(),
      };
      keeper.membership.updated_at = now;
      await keeper.membership.save();
    }

    if (revokeIds.length > 0) {
      await WorkspaceMembership.updateMany(
        { _id: { $in: revokeIds } },
        { $set: { status: "revoked", updated_at: now } },
      );
    }
  }
}

function dedupeStaffMembersByEmail(staffMembers) {
  const byEmail = new Map();

  for (const member of staffMembers) {
    const email = typeof member.email === "string" ? member.email.trim().toLowerCase() : "";

    if (!email) {
      continue;
    }

    const existing = byEmail.get(email);

    if (!existing) {
      byEmail.set(email, member);
      continue;
    }

    const score = (entry) => {
      let value = 0;
      if (entry.clerkUserId) {
        value += 4;
      }
      if (entry.status === "active") {
        value += 2;
      }
      return value;
    };

    if (score(member) >= score(existing)) {
      byEmail.set(email, member);
    }
  }

  const dedupedEmails = new Set(byEmail.keys());

  return staffMembers.filter((member) => {
    const email = typeof member.email === "string" ? member.email.trim().toLowerCase() : "";
    if (!email) {
      return true;
    }

    return dedupedEmails.has(email) && byEmail.get(email) === member;
  });
}

function serializeInvitedStaffMember({ membership }) {
  const permissions = membership && membership.permissions_json ? membership.permissions_json : {};
  const email =
    (typeof permissions.email === "string" && permissions.email.trim()) ||
    "pending-invite@unknown.local";
  const username =
    (typeof permissions.username === "string" && permissions.username.trim()) ||
    email.split("@")[0] ||
    null;

  return {
    id: String(membership._id),
    clerkUserId: null,
    username,
    email,
    firstName: "",
    lastName: "",
    role: "staff",
    status: membership.status || "invited",
    streamerUserId: null,
    workspaceId: membership.workspace_id || null,
    modules: Array.isArray(permissions.modules) ? permissions.modules : [],
    joinedAt: membership.joined_at || null,
    createdAt: membership.created_at || null,
    source: permissions.source || "clerk-organization-invite",
  };
}

async function listStaffMembers({ clerkUserId }) {
  const seller = await findAuthenticatedSeller(clerkUserId);
  const workspace = await ensureSellerWorkspace(seller);

  await syncWorkspaceOrganizationMembers({ clerkUserId, workspace });
  await getActiveStaffWithUsers(workspace._id, { revokeOrphanMemberships: true });

  const memberships = await WorkspaceMembership.find({
    workspace_id: workspace._id,
    role: "staff",
    status: { $in: ["active", "invited"] },
  }).sort({ created_at: -1, joined_at: -1 });

  const userIds = memberships.map((membership) => membership.user_id).filter(Boolean);
  const users = await User.find({ _id: { $in: userIds } });
  const userMap = new Map(users.map((user) => [user._id, user]));

  const ownerUserId = workspace.owner_user_id ? String(workspace.owner_user_id) : null;

  const staff = memberships
    .map((membership) => {
      const user = membership.user_id ? userMap.get(membership.user_id) : null;

      if (user) {
        if (ownerUserId && String(user._id) === ownerUserId) {
          return null;
        }

        return serializeStaffMember({ user, membership });
      }

      if (membership.status === "invited") {
        return serializeInvitedStaffMember({ membership });
      }

      return null;
    })
    .filter(Boolean);

  return {
    staff: dedupeStaffMembersByEmail(staff),
  };
}

async function getStaffOrderManagementSnapshot({ clerkUserId, limit = 100 }) {
  const user = await User.findOne({ clerk_user_id: clerkUserId });

  if (!user) {
    throw createHttpError(404, "User account was not found.");
  }

  if (user.user_type !== "staff") {
    throw createHttpError(403, "Only staff members can access this endpoint.");
  }

  if (!user.parent_seller_user_id) {
    throw createHttpError(404, "Parent seller was not found for this staff account.");
  }

  const seller = await User.findOne({ _id: user.parent_seller_user_id, user_type: "seller" });
  if (!seller || !seller.clerk_user_id) {
    throw createHttpError(404, "Parent seller profile is missing or invalid.");
  }

  const parentSellerClerkUserId = seller.clerk_user_id;
  const latestStats = await WhatnotLiveStatsSnapshot.findOne({
    platform: "whatnot",
    clerk_user_id: parentSellerClerkUserId,
  }).sort({ synced_at: -1, updated_at: -1 });

  const safeLimit = Number.isFinite(Number(limit)) ? Math.max(1, Math.min(200, Number(limit))) : 100;
  const shipments = await WhatnotShipmentDetail.find({
    platform: "whatnot",
    clerk_user_id: parentSellerClerkUserId,
  })
    .sort({ synced_at: -1, updated_at: -1 })
    .limit(safeLimit);

  return {
    stats: latestStats
      ? {
          liveId: latestStats.live_id || null,
          statistic: latestStats.statistic_payload || null,
          syncedAt: latestStats.synced_at || null,
          updatedAt: latestStats.updated_at || null,
        }
      : null,
    shipments: shipments.map((item) => ({
      shipmentKey: item.shipment_key || null,
      shipmentIdInput: item.shipment_id_input || null,
      shipmentGlobalId: item.shipment_global_id || null,
      shipment: item.shipment_payload || null,
      syncedAt: item.synced_at || null,
      updatedAt: item.updated_at || null,
    })),
    source: "db",
    parentSellerClerkUserId,
  };
}

async function createStaffMember({ clerkUserId, username, email, password }) {
  const normalizedUsername = normalizeUsername(username);
  const normalizedEmail = normalizeEmail(email);
  const normalizedPassword = normalizePassword(password);
  const { firstName, lastName } = buildStaffNameParts(normalizedUsername);

  if (!normalizedUsername) {
    throw createHttpError(400, "Username is required.");
  }

  if (!normalizedEmail) {
    throw createHttpError(400, "Email is required.");
  }

  if (!normalizedPassword || normalizedPassword.length < 8) {
    throw createHttpError(400, "Password must be at least 8 characters long.");
  }

  const seller = await findAuthenticatedSeller(clerkUserId);
  const workspace = await ensureSellerWorkspace(seller);

  const existingUser = await User.findOne({ email: normalizedEmail });

  if (existingUser) {
    throw createHttpError(409, "A user with this email already exists.");
  }

  const existingMembership = await WorkspaceMembership.findOne({
    workspace_id: workspace._id,
    "permissions_json.username": normalizedUsername,
  });

  if (existingMembership) {
    throw createHttpError(409, "This username is already in use for your team.");
  }

  const clerkClient = getClerkClient();
  let clerkUser = null;

  try {
    clerkUser = await clerkClient.users.createUser({
      emailAddress: [normalizedEmail],
      password: normalizedPassword,
      firstName,
      lastName,
      skipPasswordChecks: true,
      publicMetadata: {
        role: "staff",
        dashboardRole: "streamer",
      },
      privateMetadata: {
        parentSellerUserId: seller._id,
        sellerWorkspaceId: workspace._id,
        role: "staff",
      },
      unsafeMetadata: {
        role: "staff",
        parentSellerUserId: seller._id,
        sellerWorkspaceId: workspace._id,
      },
    });
  } catch (error) {
    throw normalizeClerkError(error, "Unable to create the Clerk staff account.");
  }

  try {
    await ensureStaffClerkOrganizationMembership({
      clerkClient,
      clerkUserId: clerkUser.id,
      workspace,
    });
  } catch (error) {
    await clerkClient.users.deleteUser(clerkUser.id).catch(() => null);
    throw error;
  }

  let user = null;
  let membership = null;

  try {
    const now = new Date();
    user = new User({
      clerk_user_id: clerkUser.id,
      email: normalizedEmail,
      first_name: clerkUser.firstName || firstName,
      last_name: clerkUser.lastName || lastName,
      user_type: "staff",
      parent_seller_user_id: seller._id,
      status: "active",
      created_at: now,
      updated_at: now,
    });

    await user.save();

    membership = new WorkspaceMembership({
      workspace_id: workspace._id,
      user_id: user._id,
      role: "staff",
      permissions_json: {
        username: normalizedUsername,
        modules: [],
      },
      status: "active",
      joined_at: now,
      created_at: now,
      updated_at: now,
    });

    await membership.save();

    const loginUrl = buildLoginUrl();
    const streamerName = buildStreamerDisplayName(seller);
    const inviteAlreadySentAt = membership.permissions_json && membership.permissions_json.staff_invite_email_sent_at
      ? membership.permissions_json.staff_invite_email_sent_at
      : null;
    let emailSent = Boolean(inviteAlreadySentAt);
    let emailError = null;

    if (!inviteAlreadySentAt) {
      try {
        await sendStaffWelcomeEmail({
          to: normalizedEmail,
          password: normalizedPassword,
          loginUrl,
          streamerName,
        });

        membership.permissions_json = {
          ...membership.permissions_json,
          staff_invite_email_sent_at: new Date(),
        };
        membership.updated_at = new Date();
        await membership.save();
        emailSent = true;
      } catch (error) {
        emailSent = false;
        emailError = getEmailDeliveryErrorMessage(error);
      }
    }

    return {
      member: serializeStaffMember({ user, membership }),
      emailError,
      emailSent,
      loginUrl,
      message: "Staff member created successfully.",
    };
  } catch (error) {
    if (membership) {
      await WorkspaceMembership.deleteOne({ _id: membership._id }).catch(() => null);
    }

    if (user) {
      await User.deleteOne({ _id: user._id }).catch(() => null);
    }

    if (clerkUser && clerkUser.id) {
      await clerkClient.users.deleteUser(clerkUser.id).catch(() => null);
    }
    throw error;
  }
}

module.exports = {
  createStaffMember,
  formatStaffDisplayName,
  getActiveStaffWithUsers,
  getStaffOrderManagementSnapshot,
  listStaffMembers,
};