// models/User.js
const mongoose = require("mongoose");
const uuid = require("../utils/uuid");

const UserSchema = new mongoose.Schema({
  _id: { type: String, default: uuid },

  clerk_user_id: { type: String, unique: true, sparse: true },
  email: { type: String, unique: true },
  password_hash: String,
  first_name: String,
  last_name: String,
  parent_seller_user_id: {
    type: String,
    ref: "User",
    default: null,
  },

  active_workspace_id: {
    type: String,
    ref: "SellerWorkspace",
    default: null,
  },

  user_type: {
    type: String,
    enum: ["seller", "moderator", "admin", "staff"],
  },

  status: {
    type: String,
    enum: ["active", "inactive", "pending", "blocked", "deleted"],
    default: "active",
  },

  stripe_customer_id: String,

  whatnot_seller_id: { type: String, default: null },

  created_at: { type: Date, default: Date.now },
  updated_at: { type: Date, default: Date.now },
});

module.exports = mongoose.model("User", UserSchema);